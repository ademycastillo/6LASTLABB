/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serie.pkg1;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class Serie1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int m;
        int c;
        
        System.out.println("ingreseel valor de m");
        Scanner d1= new Scanner(System.in);
        m = d1.nexInt();
        
        System.out.println("ingreseel valor de c");
        Scanner d2 =new Scanner(System.in);
        c = d2.nexInt();
        
        System.out.println("R" + m + c / 2);
        
        
    }
    
}
